<?php
	use \Core\Route;
	
	return [
		new Route('/hello/',   'hello', 'index'),
		new Route('/page/:id/', 'page', 'one'),
		new Route('/pages/',   'page', 'all'),
	];
?>