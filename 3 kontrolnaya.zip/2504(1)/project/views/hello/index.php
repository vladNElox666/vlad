<?php
	namespace Project\Controllers;
	use \Core\Controller;
	
	class PageController extends Controller
	{
		public function show1()
		{
			echo '1';
		}
		
		public function show2()
		{
			echo '2';
		}
	}
?>

Все работает!