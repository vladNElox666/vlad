<?php
	namespace Project\Controllers;
	use \Core\Controller;
	
	class TestController extends Controller
	{
		public function act1()
		{
			echo '4321';
		}
		
		public function act2()
		{
			echo '22222s';
		}
		public function act3()
		{
			echo '4';
		}
	}
?>