<?php
	header('Content-Type: text/html; charset=utf-8');
	$x = $_POST['n'];
	$y = $_POST['s'];
	$z = $x + $y;
	echo $x.' + '.$y.' = '.$z.'<br>';
	echo ' <a href="indexi.html">Вернуться назад</a>';
?>