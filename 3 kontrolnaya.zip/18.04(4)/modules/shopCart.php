<?php
	require_once '/modules/shop/cart/page.php';
	
	$modulesCartPage = new \modules\Shop\Cart\Page;
?>