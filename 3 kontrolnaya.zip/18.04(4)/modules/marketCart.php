<?php
	require_once '/modules/market/cart/page.php';
	
	$modulesCartPage = new \modules\Market\Cart\Page;
?>