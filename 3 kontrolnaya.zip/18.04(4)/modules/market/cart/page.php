<?php
	namespace Modules\Market\Cart;
	
	class Page
	{
		
	}
?>