<?php
	namespace Modules\Shop\Cart;
	
	class Page
	{
		
	}
?>