<?php
header('content-type: text/html; charset=utf-8');
require_once 'cat.php';

$pet1 = new cat('Василий', 'Сфинкс');
$pet1->display();

?>