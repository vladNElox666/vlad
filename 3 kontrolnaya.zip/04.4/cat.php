<?php
require_once 'pet.php';

class cat extends pet {
	public function voice() {
		echo 'Мяу-мяу<br>';
	}
}

?>