<?php
header('content-type:text/html; charset=utf-8');
require_once 'student.php';

$s1 = new student('Иван', 'Иванов', 'Иванович', 'И-01');
$s2 = new student('Дарья', 'Дарьева', 'Дарьевна', 'И-01');

$s1->display(); 
$s2->display();
?>