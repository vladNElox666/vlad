<?php

interface Strategy {
	public function execute($a, $b);
}

?>