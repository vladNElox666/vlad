<?php
	require_once '/modules/cart/page.php';
	
	$modulesCartPage = new \modules\Cart\Page;
?>