<?php
	namespace Modules\Cart;
	
	class Page
	{
		
	}
?>