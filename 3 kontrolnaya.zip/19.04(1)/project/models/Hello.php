<?php
	namespace Project\Models;
	use \Core\Model;
	
	class Hello extends Model
	{
		
	}
