<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'student.php';
require_once 'group.php';

$group1 = new Group(1, 'и-01');
$group2 = new Group(2, 'и-02');
$group3 = new Group(3, 'и-03');

$s1 = new student('Иван', 'Иванов', 'Иванович', $group1);
$s2 = new student('Дарья', 'Дарьева', 'Дарьевна', $group1);

$s1->display();
$s2->display();
?>