<?php

interface QuackBehavior{
	public function Quacks();
}
?> 