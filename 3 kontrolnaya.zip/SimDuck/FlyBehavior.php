<?php

interface FlyBehavior{
	public function fly();
}
?>