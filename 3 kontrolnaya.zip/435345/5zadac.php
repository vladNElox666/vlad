<?php
	header('Content-Type: text/html; charset=utf-8');
	$files = array('1.txt', '2.txt', '3.txt');
	$str = '';
	for ($i=0; $i<count($files); $i++) {
		$name = $files[$i];
		$str .= file_get_contents($name);
	}
	file_put_contents('new.txt', $str);
	echo $str;
?>