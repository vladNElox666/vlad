<?php
	namespace core;
	
	class controller
	{
		
	}
?>