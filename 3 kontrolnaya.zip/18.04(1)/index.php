<?php
	require_once '/core/controller.php';
	require_once '/project/cotroller.php';
	
	$coreController = new \core\controller;
	$projectController = new \project\controller;
?>