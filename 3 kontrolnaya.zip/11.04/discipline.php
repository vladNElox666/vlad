<?php

class Disciplines {

}

?>