<?php

interface iProgrammer {
	public function addLang($l);
	public function getLangs();
}

?>