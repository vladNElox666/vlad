$(document).ready(function() {


	$("#accordion").accordion();

});

$(document).ready(function() {

   $("#el1,#el2,#el3,#el4").button();
   $("#group1,#group2").buttonset();

});

$(document).ready(function() {

$("#auto1").autocomplete({source:["Пёс","Мак","Лук","Чел","Ёж","Кот","Коп"]});

});
